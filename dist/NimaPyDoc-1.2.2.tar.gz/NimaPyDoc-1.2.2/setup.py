from setuptools import setup,find_packages


setup(
    name="NimaPyDoc",
    version="1.2.2",
    packages=find_packages(),

)