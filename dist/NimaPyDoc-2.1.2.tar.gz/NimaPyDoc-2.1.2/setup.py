from setuptools import setup,find_packages


setup(
    name="NimaPyDoc",
    version="2.1.2",
    packages=find_packages(),

)